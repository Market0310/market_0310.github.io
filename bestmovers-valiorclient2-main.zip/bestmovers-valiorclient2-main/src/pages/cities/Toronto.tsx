import CityPageTemplate from '@/components/CityPageTemplate';
import cityImage from '@/assets/city-background.jpg';

const TorontoPage = () => {
  const cityData = {
    cityName: "Toronto",
    province: "ON",
    heroImage: cityImage,
    phoneNumber: "0000000000",
    description: "Toronto, Canada's largest city and financial capital, is home to over 6 million residents in the Greater Toronto Area. This cosmopolitan metropolis offers an incredible diversity of neighborhoods, from the iconic CN Tower area downtown to charming districts like The Beaches and Leslieville. Our Toronto moving team has extensive experience throughout the GTA, understanding the unique logistics of this bustling city, from navigating busy downtown streets to serving the sprawling suburban communities that make up the world's fourth-largest metropolitan area.",
    landmarks: "Whether you're relocating near the famous Distillery District, the trendy King Street West, the historic Casa Loma area, or moving to one of Toronto's many distinctive neighborhoods like Yorkville, The Annex, or Liberty Village, our team knows the city's intricate layout. We're experienced with moves in prestigious areas like Rosedale and Forest Hill, emerging neighborhoods like Junction Triangle and Riverside, and the diverse suburban communities throughout Mississauga, Markham, and Vaughan.",
    serviceAreas: [
      { area: "Downtown Toronto", distance: "0-5 km", driveTime: "20-45 min" },
      { area: "Mississauga", distance: "25 km", driveTime: "35-60 min" },
      { area: "Markham", distance: "30 km", driveTime: "40-70 min" },
      { area: "Vaughan", distance: "35 km", driveTime: "45-75 min" },
      { area: "Brampton", distance: "40 km", driveTime: "50-80 min" },
      { area: "Richmond Hill", distance: "25 km", driveTime: "35-65 min" },
      { area: "Oakville", distance: "35 km", driveTime: "45-70 min" },
      { area: "Pickering", distance: "40 km", driveTime: "50-75 min" },
      { area: "Ajax", distance: "45 km", driveTime: "55-85 min" }
    ],
    localServices: [
      "Residential moving throughout Toronto and GTA",
      "Financial district corporate relocations",
      "Luxury condo moves in prestigious buildings",
      "University of Toronto student services",
      "Entertainment industry relocations",
      "International moving coordination through Pearson",
      "Secure storage facilities across the GTA",
      "Express same-day service in core Toronto"
    ],
    testimonials: [
      {
        name: "Alexandra Chen",
        neighborhood: "King West",
        text: "Moving from our King West condo to a house in Leslieville required perfect timing. The team navigated downtown Toronto traffic and building restrictions flawlessly.",
        rating: 5
      },
      {
        name: "James Wilson",
        neighborhood: "Rosedale",
        text: "Our family's move from Rosedale to Oakville involved valuable antiques and artwork. Our movers treated everything with museum-quality care.",
        rating: 5
      }
    ],
    faqs: [
      {
        question: "How do you handle Toronto's traffic and parking restrictions?",
        answer: "Our Toronto team is expert at navigating the city's traffic patterns and obtaining necessary parking permits for moving trucks in restricted downtown areas."
      },
      {
        question: "Do you coordinate moves through Toronto Pearson Airport?",
        answer: "Yes, we work with international partners to coordinate relocations through Pearson, including customs clearance and logistics coordination."
      },
      {
        question: "Can you handle moves in Toronto's luxury condo buildings?",
        answer: "Absolutely. We're experienced with Toronto's premium buildings, including complex concierge requirements, elevator reservations, and building-specific protocols."
      },
      {
        question: "Do you serve all areas of the Greater Toronto Area?",
        answer: "Yes, we provide comprehensive coverage throughout the entire GTA, from downtown Toronto to all surrounding municipalities and suburbs."
      }
    ]
  };

  return <CityPageTemplate {...cityData} />;
};

export default TorontoPage;