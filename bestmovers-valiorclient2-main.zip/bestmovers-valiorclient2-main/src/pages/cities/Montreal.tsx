import CityPageTemplate from '@/components/CityPageTemplate';
import cityImage from '@/assets/city-background.jpg';

const MontrealPage = () => {
  const cityData = {
    cityName: "Montreal",
    province: "QC",
    heroImage: cityImage,
    phoneNumber: "0000000000",
    description: "Montreal, Quebec's largest city and cultural heart, is home to over 4 million residents in the greater metropolitan area. This vibrant francophone metropolis combines Old World European charm with North American dynamism, from the cobblestone streets of Old Montreal to the trendy Plateau Mont-Royal. Our Montreal moving team is fully bilingual and understands the unique character of this historic city, from navigating the narrow streets of traditional neighborhoods to managing moves in modern downtown towers.",
    landmarks: "Whether you're moving near the iconic Notre-Dame Basilica, the bustling Saint-Laurent Boulevard, the scenic Mount Royal park, or relocating to one of Montreal's distinct boroughs like Westmount, Outremont, or Verdun, our team knows the city's rich tapestry of neighborhoods. We're experienced with moves in historic areas like Old Montreal and Mile End, trendy districts like the Plateau and Little Italy, and suburban communities throughout Laval, Longueuil, and the South Shore.",
    serviceAreas: [
      { area: "Downtown Montreal", distance: "0-5 km", driveTime: "20-40 min" },
      { area: "Plateau Mont-Royal", distance: "5 km", driveTime: "15-30 min" },
      { area: "Westmount", distance: "8 km", driveTime: "20-35 min" },
      { area: "Laval", distance: "20 km", driveTime: "30-50 min" },
      { area: "Longueuil", distance: "15 km", driveTime: "25-40 min" },
      { area: "Brossard", distance: "18 km", driveTime: "25-45 min" },
      { area: "Saint-Lambert", distance: "12 km", driveTime: "20-35 min" },
      { area: "Dollard-des-Ormeaux", distance: "25 km", driveTime: "35-55 min" },
      { area: "Terrebonne", distance: "35 km", driveTime: "45-65 min" }
    ],
    localServices: [
      "Services de déménagement résidentiel à Montréal",
      "Déménagement commercial et d'entreprise",
      "Services bilingues (français/anglais)",
      "Déménagement d'étudiants (McGill, UQAM, Concordia)",
      "Déménagement dans le Vieux-Montréal historique",
      "Transport d'œuvres d'art et d'antiquités",
      "Entreposage sécurisé dans la région métropolitaine",
      "Coordination de déménagements internationaux"
    ],
    testimonials: [
      {
        name: "Sophie Tremblay",
        neighborhood: "Le Plateau",
        text: "Notre déménagement du Plateau vers Outremont a été impeccable. L'équipe bilingue a su naviguer les rues étroites et a traité nos meubles antiques avec grand soin.",
        rating: 5
      },
      {
        name: "Andrew Patterson",
        neighborhood: "Westmount",
        text: "Moving from our Westmount home to downtown required careful coordination. The team was perfectly bilingual and understood both the English and French requirements.",
        rating: 5
      }
    ],
    faqs: [
      {
        question: "Offrez-vous des services en français à Montréal?",
        answer: "Oui, notre équipe montréalaise est entièrement bilingue et peut fournir tous les services en français, ce qui est essentiel dans la métropole québécoise."
      },
      {
        question: "Can you handle moves in Montreal's historic neighborhoods?",
        answer: "Absolutely. We're experienced with Old Montreal's narrow streets, heritage building requirements, and the unique challenges of moving in historic areas."
      },
      {
        question: "Do you serve the universities (McGill, UQAM, Concordia)?",
        answer: "Yes, we provide specialized student moving services for all Montreal universities, understanding both campus housing and off-campus rental markets."
      },
      {
        question: "Pouvez-vous gérer les exigences linguistiques du Québec?",
        answer: "Oui, nous comprenons parfaitement les exigences linguistiques et culturelles du Québec et offrons un service entièrement adapté au contexte montréalais."
      }
    ]
  };

  return <CityPageTemplate {...cityData} />;
};

export default MontrealPage;