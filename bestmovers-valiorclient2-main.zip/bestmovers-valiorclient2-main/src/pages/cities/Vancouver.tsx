import CityPageTemplate from '@/components/CityPageTemplate';
import cityImage from '@/assets/city-background.jpg';

const VancouverPage = () => {
  const cityData = {
    cityName: "Vancouver",
    province: "BC",
    heroImage: cityImage,
    phoneNumber: "0000000000",
    description: "Vancouver, consistently ranked among the world's most livable cities, is home to over 2.5 million residents in the greater metropolitan area. Nestled between the Pacific Ocean and the Coast Mountains, this vibrant West Coast city offers everything from downtown high-rises with ocean views to charming neighborhoods like Kitsilano and Commercial Drive. Our Vancouver moving team understands the unique challenges of this coastal city, from navigating narrow streets in older neighborhoods to managing moves in luxury waterfront properties.",
    landmarks: "Whether you're moving near the iconic Stanley Park, the bustling Granville Island, the scenic False Creek, or relocating to one of Vancouver's diverse neighborhoods like Yaletown, Gastown, or the West End, our team knows the city intimately. We're experienced with moves in prestigious areas like Shaughnessy and Point Grey, trendy districts like Main Street and Commercial Drive, and family-friendly communities throughout Richmond, Burnaby, and the North Shore.",
    serviceAreas: [
      { area: "Downtown Vancouver", distance: "0-5 km", driveTime: "15-30 min" },
      { area: "West Vancouver", distance: "15 km", driveTime: "25-40 min" },
      { area: "North Vancouver", distance: "12 km", driveTime: "20-35 min" },
      { area: "Burnaby", distance: "10 km", driveTime: "20-30 min" },
      { area: "Richmond", distance: "15 km", driveTime: "25-35 min" },
      { area: "Surrey", distance: "30 km", driveTime: "40-60 min" },
      { area: "Coquitlam", distance: "25 km", driveTime: "35-50 min" },
      { area: "Delta", distance: "25 km", driveTime: "35-45 min" },
      { area: "Langley", distance: "45 km", driveTime: "50-70 min" }
    ],
    localServices: [
      "Residential moving throughout Vancouver and Lower Mainland",
      "High-rise condo moves with ocean and mountain views",
      "International relocation coordination through YVR",
      "Luxury waterfront property relocations",
      "Film industry crew and equipment moving",
      "UBC and SFU student moving services",
      "Climate-controlled storage with ocean access",
      "Green moving options with eco-friendly practices"
    ],
    testimonials: [
      {
        name: "Emma Thompson",
        neighborhood: "Yaletown",
        text: "Moving from our Yaletown condo to a house in Kitsilano was seamless. The team handled our modern furniture and electronics with exceptional care.",
        rating: 5
      },
      {
        name: "Michael Zhang",
        neighborhood: "West Vancouver",
        text: "Our waterfront home in West Van required special logistics. Our movers coordinated perfectly with our strata and handled our valuable art collection expertly.",
        rating: 5
      }
    ],
    faqs: [
      {
        question: "Do you handle moves in Vancouver's high-rise buildings?",
        answer: "Yes, we're very experienced with Vancouver's numerous condo towers, including complex building requirements, strata regulations, and coordination with concierge services."
      },
      {
        question: "Can you coordinate international moves through YVR airport?",
        answer: "Absolutely. We work with international moving partners and can coordinate logistics for moves connecting through Vancouver International Airport."
      },
      {
        question: "Do you serve the universities (UBC, SFU)?",
        answer: "Yes, we provide specialized student moving services for both UBC and SFU, including campus housing and nearby rental properties."
      },
      {
        question: "How do you handle Vancouver's rainy weather?",
        answer: "Our Vancouver team comes prepared with proper equipment and protection to ensure your belongings stay dry during the city's frequent rainfall."
      }
    ]
  };

  return <CityPageTemplate {...cityData} />;
};

export default VancouverPage;