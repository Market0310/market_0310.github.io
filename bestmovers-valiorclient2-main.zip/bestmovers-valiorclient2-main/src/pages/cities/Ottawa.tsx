import CityPageTemplate from '@/components/CityPageTemplate';
import cityImage from '@/assets/city-background.jpg';

const OttawaPage = () => {
  const cityData = {
    cityName: "Ottawa",
    province: "ON",
    heroImage: cityImage,
    phoneNumber: "0000000000",
    description: "Ottawa, Canada's capital city and home to over 1.4 million residents in the National Capital Region, offers a unique blend of government institutions, cultural landmarks, and vibrant neighborhoods. From the historic ByWard Market to the scenic Rideau Canal, this bilingual city presents distinct moving challenges and opportunities. Our Ottawa moving team understands the federal city's unique requirements, from government employee relocations to moves near embassies and cultural institutions like the National Gallery and Parliament Hill.",
    landmarks: "Whether you're moving near the iconic Parliament Buildings, the beautiful Rideau Canal (a UNESCO World Heritage site), the trendy Glebe neighborhood, or relocating to one of Ottawa's family-friendly communities like Kanata, Barrhaven, or Orleans, our team knows the capital region inside out. We're experienced with moves in historic areas like Sandy Hill and New Edinburgh, government quarters near Tunney's Pasture, and growing suburban communities throughout the Ottawa-Gatineau region.",
    serviceAreas: [
      { area: "Downtown Ottawa", distance: "0-5 km", driveTime: "15-30 min" },
      { area: "Kanata", distance: "20 km", driveTime: "25-40 min" },
      { area: "Barrhaven", distance: "18 km", driveTime: "25-35 min" },
      { area: "Orleans", distance: "25 km", driveTime: "30-45 min" },
      { area: "Nepean", distance: "15 km", driveTime: "20-35 min" },
      { area: "Gatineau, QC", distance: "10 km", driveTime: "20-35 min" },
      { area: "Gloucester", distance: "20 km", driveTime: "25-40 min" },
      { area: "Stittsville", distance: "25 km", driveTime: "30-45 min" },
      { area: "Manotick", distance: "30 km", driveTime: "35-50 min" }
    ],
    localServices: [
      "Government employee relocation services",
      "Embassy and diplomatic moving coordination",
      "Residential moving throughout Ottawa-Gatineau",
      "University of Ottawa student services",
      "Carleton University campus area moves",
      "Bilingual moving services (English/French)",
      "Parliament Hill area logistics coordination",
      "Cross-provincial moves (Ontario/Quebec)"
    ],
    testimonials: [
      {
        name: "Marie Dubois",
        neighborhood: "Glebe",
        text: "Notre déménagement du Glebe à Kanata s'est déroulé parfaitement. L'équipe était bilingue et a géré tous les détails avec professionnalisme. (Our move from Glebe to Kanata went perfectly. The team was bilingual and handled every detail professionally.)",
        rating: 5
      },
      {
        name: "Robert MacLeod",
        neighborhood: "Sandy Hill",
        text: "As a government employee relocating to Ottawa, our movers understood the specific requirements and timing needs. They made my transition to the capital seamless.",
        rating: 5
      }
    ],
    faqs: [
      {
        question: "Do you provide bilingual services in Ottawa?",
        answer: "Yes, our Ottawa team is bilingual and can provide services in both English and French, which is essential in Canada's capital region."
      },
      {
        question: "Can you handle government employee relocations?",
        answer: "Absolutely. We're experienced with federal government relocation requirements and can coordinate with HR departments for employee moves."
      },
      {
        question: "Do you move between Ontario and Quebec (Gatineau)?",
        answer: "Yes, we regularly handle cross-provincial moves between Ottawa and Gatineau, understanding the requirements for interprovincial relocations."
      },
      {
        question: "Are you familiar with embassy and diplomatic moving needs?",
        answer: "Yes, we have experience with diplomatic moves and understand the security and protocol requirements for embassy-related relocations."
      }
    ]
  };

  return <CityPageTemplate {...cityData} />;
};

export default OttawaPage;