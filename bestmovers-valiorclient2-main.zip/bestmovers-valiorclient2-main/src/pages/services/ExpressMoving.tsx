import ServicePageTemplate from '@/components/ServicePageTemplate';
import residentialImage from '@/assets/residential-moving.jpg';

const ExpressMoving = () => {
  const serviceData = {
    title: "Express Same-Day Moves",
    subtitle: "Urgent moving services when you need to relocate immediately - available 24/7",
    heroImage: residentialImage,
    description: "Life doesn't always give you weeks to plan a move. Sometimes you need to relocate immediately due to work emergencies, housing situations, family circumstances, or other urgent matters. Our Express Same-Day Moving service is specifically designed for these urgent situations, providing professional moving services with just hours of notice. We maintain a dedicated team and fleet ready for emergency moves, 24 hours a day, 7 days a week, including holidays. Our express moving service has helped hundreds of clients who needed to move immediately due to job relocations, housing emergencies, relationship changes, or unexpected life events. While same-day moves require quick action, we never compromise on the quality of service or care for your belongings. Our experienced express moving team arrives fully equipped with all necessary materials and equipment to handle your urgent relocation professionally and efficiently. We understand that urgent moves can be stressful, so we work quickly while maintaining our high standards of professionalism and care. Our express service includes rapid response, immediate packing assistance, same-day transportation, and priority handling to ensure your urgent move is completed safely and on time.",
    features: [
      "Available 24/7 including weekends and holidays",
      "Response time within 2-4 hours of your call",
      "Dedicated express moving team always on standby",
      "All packing materials and equipment included",
      "Priority scheduling over regular bookings",
      "Streamlined process for maximum efficiency",
      "Same-day completion for most local moves",
      "Emergency coordination with other services if needed",
      "Flexible payment options for urgent situations"
    ],
    process: [
      {
        step: "Immediate Response",
        description: "Call us anytime, day or night. We'll assess your urgent moving needs and dispatch a team within 2-4 hours."
      },
      {
        step: "Rapid Assessment",
        description: "Our team arrives quickly to assess your belongings and provide an immediate quote for your same-day move."
      },
      {
        step: "Express Packing",
        description: "We immediately begin packing your belongings using efficient techniques designed for speed without sacrificing protection."
      },
      {
        step: "Priority Transportation",
        description: "Your items are loaded and transported with priority scheduling to ensure same-day delivery to your new location."
      },
      {
        step: "Quick Setup",
        description: "We unload and provide basic unpacking assistance to help you get settled immediately in your new space."
      }
    ],
    pricing: {
      title: "Emergency Service Pricing",
      description: "Premium rates for immediate service with transparent pricing and no hidden fees.",
      features: [
        "Emergency service rates apply",
        "All materials included",
        "24/7 availability",
        "Priority scheduling",
        "Rapid response guarantee",
        "Flexible payment options",
        "Complete insurance coverage"
      ]
    },
    faqs: [
      {
        question: "How quickly can you respond for a same-day move?",
        answer: "We guarantee response within 2-4 hours of your call, 24/7. For extremely urgent situations, we can often respond faster depending on team availability."
      },
      {
        question: "Do you charge extra for same-day service?",
        answer: "Yes, express same-day moves include premium rates due to the immediate availability and priority scheduling required. We provide transparent pricing upfront."
      },
      {
        question: "What size moves can you handle same-day?",
        answer: "We can handle most residential and small office moves same-day. Larger moves may require additional time, but we'll work with you to find the fastest solution."
      },
      {
        question: "Are you really available 24/7?",
        answer: "Yes, we maintain emergency response capability 24 hours a day, 7 days a week, including holidays. Someone is always available to take your call."
      },
      {
        question: "What if I need to move in the middle of the night?",
        answer: "We can accommodate middle-of-the-night moves when necessary. Night moves may have additional considerations for building access and noise, which we'll coordinate."
      },
      {
        question: "Can you help with emergency storage if needed?",
        answer: "Yes, we can arrange immediate access to storage facilities if your same-day move requires temporary storage solutions."
      }
    ],
    testimonial: {
      name: "Lisa Thompson",
      location: "Calgary, AB",
      text: "I had to move out within 6 hours due to an emergency situation. Our movers arrived within 3 hours and had me completely moved by the end of the day. They were professional and compassionate during a very difficult time.",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default ExpressMoving;