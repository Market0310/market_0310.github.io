import ServicePageTemplate from '@/components/ServicePageTemplate';
import residentialImage from '@/assets/residential-moving.jpg';

const ResidentialMoving = () => {
  const serviceData = {
    title: "Residential Moving Services",
    subtitle: "Professional home moving services across Canada with flat-rate pricing and full insurance",
    heroImage: residentialImage,
    description: "Moving to a new home should be exciting, not stressful. Our residential moving services take care of every detail of your home relocation, from careful packing of your belongings to safe transportation and unpacking at your new residence. With over 500 successful residential moves completed, we understand that your home contains not just furniture and belongings, but memories and treasures that require the utmost care and attention. Our fully trained and insured moving professionals use industry-leading techniques and equipment to ensure your possessions arrive safely at your new home. Whether you're moving across town or across the country, we provide transparent flat-rate pricing with no hidden fees, so you know exactly what to expect. From studio apartments to large family homes, we have the expertise and equipment to handle moves of any size. Our comprehensive residential moving service includes pre-move planning, professional packing services, loading, transportation, unloading, and unpacking assistance. We also offer storage solutions if you need temporary or long-term storage during your transition.",
    features: [
      "Professional packing and unpacking services using high-quality materials",
      "Experienced team trained in safe handling of furniture and fragile items",
      "Full insurance coverage for complete peace of mind during your move",
      "Flat-rate pricing with no hidden fees or surprise charges",
      "Flexible scheduling including evenings and weekends",
      "Free pre-move consultation and detailed moving estimate",
      "Specialty handling for pianos, artwork, and valuable items",
      "Assembly and disassembly of furniture and appliances",
      "Clean-up service and debris removal after the move"
    ],
    process: [
      {
        step: "Free In-Home Consultation",
        description: "Our moving specialist visits your home to assess your belongings and provide an accurate, written estimate with flat-rate pricing."
      },
      {
        step: "Pre-Move Planning",
        description: "We create a detailed moving plan tailored to your specific needs, including timeline, packing requirements, and any special considerations."
      },
      {
        step: "Professional Packing",
        description: "Our trained team carefully packs your belongings using premium materials, with special attention to fragile and valuable items."
      },
      {
        step: "Safe Transportation",
        description: "Your belongings are loaded onto our equipped moving trucks and transported safely to your new home with real-time tracking."
      },
      {
        step: "Unpacking & Setup",
        description: "We unload, unpack, and help set up your new home according to your preferences, ensuring a smooth transition."
      }
    ],
    pricing: {
      title: "Transparent Flat-Rate Pricing",
      description: "No hourly rates, no surprise fees. Get a guaranteed price for your entire move.",
      features: [
        "All labor costs included",
        "Transportation and fuel costs",
        "Basic packing materials",
        "Loading and unloading",
        "Assembly/disassembly service",
        "Full insurance coverage",
        "24/7 customer support"
      ]
    },
    faqs: [
      {
        question: "How far in advance should I book my residential move?",
        answer: "We recommend booking your residential move at least 2-4 weeks in advance, especially during peak moving season (May-September). However, we understand that some moves are urgent, and we offer same-day and next-day services when possible."
      },
      {
        question: "What's included in your residential moving service?",
        answer: "Our comprehensive service includes pre-move consultation, professional packing materials, loading, transportation, unloading, and basic unpacking. We also provide furniture disassembly/assembly, appliance disconnection/reconnection, and clean-up services."
      },
      {
        question: "How do you protect my furniture and belongings?",
        answer: "We use professional-grade packing materials including bubble wrap, moving blankets, and custom crating for valuable items. All our movers are trained in proper lifting and handling techniques, and we carry full insurance coverage for your protection."
      },
      {
        question: "Do you provide packing materials?",
        answer: "Yes, we provide all necessary packing materials including boxes, tape, bubble wrap, and moving blankets. We can also provide specialty boxes for items like dishes, wardrobes, and electronics."
      },
      {
        question: "What if my new home isn't ready on moving day?",
        answer: "We offer flexible scheduling and short-term storage solutions if your new home isn't ready. Our climate-controlled storage facility can safely house your belongings until you're ready for delivery."
      },
      {
        question: "How is the cost calculated for residential moves?",
        answer: "We provide flat-rate pricing based on the size of your move, distance, and specific services required. This means no hourly rates or surprise charges - you'll know the exact cost upfront with our free in-home estimate."
      }
    ],
    testimonial: {
      name: "Sarah Chen",
      location: "Calgary, AB",
      text: "Our movers made our family's move from Calgary to Edmonton completely stress-free. They handled our piano, artwork, and even our kids' toys with incredible care. The flat-rate pricing was exactly as quoted - no surprises!",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default ResidentialMoving;