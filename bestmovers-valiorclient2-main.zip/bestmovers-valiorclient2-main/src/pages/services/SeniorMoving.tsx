import ServicePageTemplate from '@/components/ServicePageTemplate';
import residentialImage from '@/assets/residential-moving.jpg';

const SeniorMoving = () => {
  const serviceData = {
    title: "Senior & Assisted Living Moves",
    subtitle: "Compassionate and specialized moving services designed for seniors transitioning to new homes",
    heroImage: residentialImage,
    description: "Moving can be emotionally challenging and physically demanding, especially for seniors transitioning to assisted living facilities, retirement communities, or downsizing to smaller homes. Our senior moving services are designed with extra care, patience, and understanding to make this important life transition as smooth and stress-free as possible. We recognize that seniors often have a lifetime of possessions and memories to sort through, and we approach each move with the sensitivity and respect it deserves. Our specially trained team understands the unique needs of senior clients, including mobility considerations, health concerns, and the emotional aspects of leaving a longtime family home. We work at a comfortable pace, provide extra assistance with decision-making about belongings, and offer additional services like helping with the setup of the new living space. Our senior moving specialists can help coordinate with family members, assist with donations of unwanted items, and even help with the sale of furniture or household goods. We understand that this move represents more than just changing addresses - it's often a significant life transition that requires extra care and support.",
    features: [
      "Specialized training in senior care and mobility considerations",
      "Patient, compassionate approach with extra time for decision-making",
      "Assistance with sorting and organizing belongings for downsizing",
      "Coordination with family members and care facilities",
      "Help with donation pickups and disposal of unwanted items",
      "Gentle handling of sentimental and fragile items",
      "Setup assistance at the new residence or care facility",
      "Flexible scheduling to accommodate medical appointments",
      "Additional services like furniture arrangement and unpacking"
    ],
    process: [
      {
        step: "Compassionate Consultation",
        description: "We meet with the senior and family members to understand specific needs, concerns, and preferences for the move."
      },
      {
        step: "Sorting & Downsizing Assistance",
        description: "Our team helps sort through belongings, identifying items to keep, donate, or dispose of, working at a comfortable pace."
      },
      {
        step: "Careful Packing & Protection",
        description: "We pack belongings with extra care, paying special attention to sentimental items and family heirlooms."
      },
      {
        step: "Coordinated Moving Day",
        description: "Our gentle, patient team handles the physical aspects of the move while providing emotional support throughout the process."
      },
      {
        step: "New Home Setup",
        description: "We help unpack and arrange the new living space to feel comfortable and familiar, making the transition easier."
      }
    ],
    pricing: {
      title: "Senior-Friendly Pricing",
      description: "Special rates for seniors with additional services included at no extra charge.",
      features: [
        "Senior discount available",
        "Extra time for packing included",
        "Donation coordination assistance",
        "Family consultation services",
        "New home setup assistance",
        "Flexible payment options",
        "Comprehensive insurance"
      ]
    },
    faqs: [
      {
        question: "Do you offer special rates for seniors?",
        answer: "Yes, we offer senior discounts and understand that many seniors are on fixed incomes. We work with families to provide affordable moving solutions without compromising on quality of service."
      },
      {
        question: "How do you help with downsizing decisions?",
        answer: "Our team is trained to patiently assist with sorting belongings, helping identify items that will fit in the new space, and coordinating donations or sales of items that won't be needed."
      },
      {
        question: "Can you coordinate with assisted living facilities?",
        answer: "Absolutely. We regularly work with assisted living facilities, retirement communities, and care homes. We understand their move-in procedures and can coordinate timing and logistics."
      },
      {
        question: "What if my parent becomes overwhelmed during the move?",
        answer: "Our team is trained to recognize signs of stress or overwhelm and can adjust our pace accordingly. We always prioritize the emotional well-being of our senior clients."
      },
      {
        question: "Do you help set up the new living space?",
        answer: "Yes, we provide setup services to help arrange furniture and unpack belongings in a way that makes the new space feel comfortable and familiar."
      },
      {
        question: "Can family members be involved in the moving process?",
        answer: "We encourage family involvement and can coordinate with multiple family members to ensure everyone is informed and comfortable with the moving plan."
      }
    ],
    testimonial: {
      name: "Dorothy and family",
      location: "Calgary, AB",
      text: "Moving my mother to assisted living was emotional for our whole family. The moving team was incredibly patient and kind, helping her feel comfortable every step of the way. They made a difficult transition much easier.",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default SeniorMoving;