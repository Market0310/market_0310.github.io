import ServicePageTemplate from '@/components/ServicePageTemplate';
import commercialImage from '@/assets/commercial-moving.jpg';

const CommercialMoving = () => {
  const serviceData = {
    title: "Office & Commercial Moving",
    subtitle: "Minimize downtime with our professional commercial relocation services designed for businesses",
    heroImage: commercialImage,
    description: "Relocating your business requires precision, planning, and minimal disruption to your operations. Our commercial moving services are specifically designed to meet the unique needs of businesses, from small offices to large corporate facilities. We understand that time is money in business, which is why we focus on efficiency and minimal downtime during your commercial relocation. Our experienced commercial moving team has successfully relocated hundreds of businesses across Canada, including law firms, medical practices, retail stores, restaurants, and corporate offices. We specialize in handling sensitive business equipment, including IT infrastructure, medical equipment, laboratory instruments, and valuable inventory. Our comprehensive commercial moving service includes detailed project planning, professional packing of office equipment, secure transportation, and setup at your new location. We work closely with your IT department to ensure proper disconnection and reconnection of computer systems and networks. Our team is trained in handling confidential documents and sensitive materials with the highest level of security and professionalism. We offer flexible scheduling including evenings, weekends, and holidays to minimize impact on your business operations.",
    features: [
      "Detailed project planning and timeline management for minimal downtime",
      "Specialized handling of IT equipment, servers, and sensitive electronics",
      "Secure transportation and handling of confidential business documents",
      "Professional disassembly and reassembly of office furniture and equipment",
      "Coordination with building management and IT departments",
      "Flexible scheduling including after-hours and weekend moves",
      "Inventory tracking and asset management throughout the move",
      "Post-move setup assistance to get your business operational quickly",
      "Full liability coverage for business equipment and assets"
    ],
    process: [
      {
        step: "Business Assessment & Planning",
        description: "We conduct a thorough assessment of your current office, equipment, and specific business needs to create a detailed moving plan."
      },
      {
        step: "Pre-Move Coordination",
        description: "Our project manager coordinates with your team, building management, and IT department to ensure smooth logistics and minimal disruption."
      },
      {
        step: "Professional Packing & Labeling",
        description: "We systematically pack and label all office items, equipment, and documents using specialized materials for business assets."
      },
      {
        step: "Secure Transportation",
        description: "Your business assets are transported in our secure, climate-controlled vehicles with real-time tracking and monitoring."
      },
      {
        step: "Setup & Operational Support",
        description: "We unpack, set up your new office space, and provide support to help get your business operational as quickly as possible."
      }
    ],
    pricing: {
      title: "Competitive Commercial Rates",
      description: "Customized pricing for businesses of all sizes with transparent, flat-rate estimates.",
      features: [
        "Project management included",
        "Specialized equipment handling",
        "After-hours moving options",
        "IT equipment setup assistance",
        "Document handling protocols",
        "Comprehensive insurance coverage",
        "Post-move support"
      ]
    },
    faqs: [
      {
        question: "How do you minimize business downtime during a commercial move?",
        answer: "We offer after-hours and weekend moving services, detailed pre-planning, and phased moving options. Our project managers work with your team to create a timeline that minimizes operational disruption."
      },
      {
        question: "Can you handle our IT equipment and servers?",
        answer: "Yes, our team is trained in handling sensitive IT equipment including servers, computers, and networking hardware. We coordinate with your IT department for proper disconnection and reconnection procedures."
      },
      {
        question: "How do you ensure security of confidential documents?",
        answer: "We follow strict security protocols for handling confidential business documents, including chain of custody procedures, secure transportation, and background-checked team members."
      },
      {
        question: "Do you provide storage for excess office items?",
        answer: "Yes, we offer secure commercial storage solutions for furniture, equipment, and documents that you don't immediately need at your new location."
      },
      {
        question: "How far in advance should we book our commercial move?",
        answer: "We recommend booking commercial moves 4-6 weeks in advance to allow for proper planning and coordination. However, we can accommodate urgent relocations when necessary."
      },
      {
        question: "What types of businesses do you move?",
        answer: "We handle all types of commercial relocations including offices, medical practices, law firms, retail stores, restaurants, warehouses, and manufacturing facilities."
      }
    ],
    testimonial: {
      name: "Michael Rodriguez",
      location: "Edmonton, AB",
      text: "Our law firm's move was handled with exceptional professionalism. They moved our entire office over the weekend, and we were fully operational Monday morning. Their attention to confidential documents was outstanding.",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default CommercialMoving;