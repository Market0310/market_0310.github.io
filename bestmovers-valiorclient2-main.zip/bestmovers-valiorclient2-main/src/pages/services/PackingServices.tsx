import ServicePageTemplate from '@/components/ServicePageTemplate';
import commercialImage from '@/assets/commercial-moving.jpg';

const PackingServices = () => {
  const serviceData = {
    title: "Packing & Unpacking Services",
    subtitle: "Professional packing services to protect your belongings with premium materials and expert techniques",
    heroImage: commercialImage,
    description: "Proper packing is the foundation of a successful move, and it's often the most time-consuming and stressful part of the relocation process. Our professional packing services take this burden off your shoulders while ensuring your belongings are protected with the highest quality materials and expert techniques. Our trained packing specialists have years of experience in handling everything from everyday household items to priceless antiques, artwork, and delicate electronics. We use only premium packing materials including acid-free tissue paper, bubble wrap, custom-cut foam, and specialized boxes designed for different types of items. Our comprehensive packing service includes detailed inventory tracking, custom crating for valuable items, and specialized techniques for fragile and unusual objects. We understand that every item in your home has value, whether monetary or sentimental, and we treat each piece accordingly. Our packing team can handle your entire home or just specific rooms or items that require special attention. We also offer partial packing services where we handle only your most fragile or valuable items while you pack the rest. After your move, our unpacking service helps you get settled quickly by unpacking boxes, arranging items, and removing all packing materials.",
    features: [
      "Premium packing materials including acid-free tissue and custom foam",
      "Specialized techniques for fragile items, artwork, and electronics",
      "Custom crating for valuable and unusual-shaped items",
      "Detailed inventory with photos and descriptions",
      "Room-by-room organization and labeling system",
      "Partial or full-service packing options",
      "Unpacking and arrangement services at destination",
      "Eco-friendly disposal of packing materials",
      "Insurance coverage for packed items"
    ],
    process: [
      {
        step: "Packing Assessment",
        description: "We evaluate your belongings to determine the best packing approach, materials needed, and create a detailed packing plan."
      },
      {
        step: "Material Preparation",
        description: "We arrive with all necessary premium packing materials and specialized equipment for your specific items."
      },
      {
        step: "Systematic Packing",
        description: "Our team packs room by room using proven techniques, with detailed labeling and inventory tracking for every box."
      },
      {
        step: "Quality Control",
        description: "Each packed box is inspected for proper protection and clearly labeled with contents and destination room."
      },
      {
        step: "Unpacking Service",
        description: "At your new home, we unpack boxes, arrange items according to your preferences, and remove all packing materials."
      }
    ],
    pricing: {
      title: "Flexible Packing Packages",
      description: "Choose from full-service packing, partial packing, or individual item packing options.",
      features: [
        "All packing materials included",
        "Professional packing techniques",
        "Detailed inventory documentation",
        "Custom crating when needed",
        "Unpacking services available",
        "Eco-friendly material disposal",
        "Full protection guarantee"
      ]
    },
    faqs: [
      {
        question: "Do you provide all packing materials?",
        answer: "Yes, we provide all necessary packing materials including boxes, tape, bubble wrap, tissue paper, and specialized materials for fragile items. All materials are included in our service fee."
      },
      {
        question: "How do you pack fragile and valuable items?",
        answer: "We use specialized techniques and materials for fragile items including custom foam cutting, double-boxing, and custom crating. Valuable items are documented with photos and handled with extra care."
      },
      {
        question: "Can you pack just certain rooms or items?",
        answer: "Absolutely. We offer partial packing services where we handle only specific rooms, fragile items, or valuable pieces while you pack the rest. This is a popular cost-saving option."
      },
      {
        question: "How long does professional packing take?",
        answer: "Packing time depends on the size of your home and number of belongings. A typical 3-bedroom home takes 1-2 days to pack completely with our full team."
      },
      {
        question: "Do you offer unpacking services?",
        answer: "Yes, we provide complete unpacking services including arranging items in your new home and removing all packing materials. This helps you get settled much faster."
      },
      {
        question: "What happens to the packing materials after unpacking?",
        answer: "We remove and dispose of all packing materials in an environmentally responsible way. Boxes and materials in good condition are recycled or donated when possible."
      }
    ],
    testimonial: {
      name: "Robert Kim",
      location: "Edmonton, AB",
      text: "The packing service was incredible. They packed our entire home including my wife's extensive china collection and my workshop tools. Everything arrived perfectly protected and they unpacked everything beautifully in our new home.",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default PackingServices;