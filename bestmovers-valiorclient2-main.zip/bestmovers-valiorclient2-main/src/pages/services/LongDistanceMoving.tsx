import ServicePageTemplate from '@/components/ServicePageTemplate';
import longDistanceImage from '@/assets/long-distance-moving.jpg';

const LongDistanceMoving = () => {
  const serviceData = {
    title: "Long-Distance & Cross-Canada Moving",
    subtitle: "Reliable cross-country moving services connecting all Canadian provinces with full tracking",
    heroImage: longDistanceImage,
    description: "Moving across provinces or across the country requires specialized expertise, careful planning, and reliable coordination that only comes with experience. Our long-distance moving services connect all Canadian provinces, from British Columbia to the Atlantic provinces, with the same level of care and professionalism you'd expect for a local move. We understand that long-distance moves involve unique challenges including timing coordination, weather considerations, border crossings, and the stress of moving far from familiar surroundings. Our experienced long-distance moving team has successfully completed thousands of cross-country relocations, earning us a reputation as one of Canada's most trusted long-distance moving companies. We use modern, well-maintained trucks equipped with GPS tracking and climate control to ensure your belongings are protected throughout the journey. Our comprehensive long-distance service includes detailed inventory management, real-time tracking updates, and coordination with local regulations in different provinces. We handle all the logistics so you can focus on settling into your new province and community. Whether you're relocating for work, family, or a new adventure, we make long-distance moving across Canada straightforward and stress-free.",
    features: [
      "Cross-country coverage connecting all Canadian provinces",
      "Real-time GPS tracking so you always know where your belongings are",
      "Climate-controlled trucks to protect your items during long journeys",
      "Detailed inventory management with photos and descriptions",
      "Coordination with provincial regulations and requirements",
      "Flexible delivery options including storage-in-transit",
      "Experienced drivers familiar with Canadian routes and weather",
      "Full insurance coverage for long-distance transportation",
      "Regular communication and updates throughout your move"
    ],
    process: [
      {
        step: "Long-Distance Consultation",
        description: "We assess your long-distance move requirements, including timeline, special items, and any provincial considerations that may apply."
      },
      {
        step: "Detailed Planning & Logistics",
        description: "Our logistics team creates a comprehensive moving plan including route planning, timing, and coordination with facilities at both ends."
      },
      {
        step: "Professional Packing & Loading",
        description: "Items are packed and loaded using long-distance moving techniques designed to protect your belongings during extended transport."
      },
      {
        step: "Tracked Transportation",
        description: "Your belongings travel in our climate-controlled trucks with real-time GPS tracking and regular progress updates."
      },
      {
        step: "Delivery & Setup",
        description: "We coordinate delivery at your new province and provide unpacking and setup services to help you settle in quickly."
      }
    ],
    pricing: {
      title: "Transparent Cross-Country Pricing",
      description: "Flat-rate pricing for long-distance moves with no hidden mileage or fuel charges.",
      features: [
        "All transportation costs included",
        "No hidden mileage charges",
        "Fuel costs included in quote",
        "GPS tracking at no extra cost",
        "Basic insurance coverage",
        "Loading and unloading services",
        "Provincial coordination included"
      ]
    },
    faqs: [
      {
        question: "How long does a cross-country move take?",
        answer: "Cross-country moves typically take 3-7 business days depending on the distance and route. We provide estimated delivery windows and keep you updated on progress throughout the journey."
      },
      {
        question: "Can I track my belongings during the move?",
        answer: "Yes, all our long-distance trucks are equipped with GPS tracking. You'll receive regular updates and can contact us anytime for current location information."
      },
      {
        question: "What if my belongings arrive before I do?",
        answer: "We offer storage-in-transit services if you need temporary storage at your destination. We can hold your belongings until you're ready for delivery."
      },
      {
        question: "How do you handle provincial regulations?",
        answer: "Our team is familiar with interprovincial moving regulations and handles all necessary paperwork and compliance requirements for moves between provinces."
      },
      {
        question: "What happens if there's bad weather during transport?",
        answer: "Our drivers are experienced in Canadian weather conditions. If severe weather affects travel, we'll communicate delays and adjust delivery schedules accordingly."
      },
      {
        question: "Is my property insured during long-distance transport?",
        answer: "Yes, we provide comprehensive insurance coverage for long-distance moves. We can also arrange additional coverage for high-value items if needed."
      }
    ],
    testimonial: {
      name: "James Mitchell",
      location: "Vancouver, BC to Toronto, ON",
      text: "Moving from Vancouver to Toronto seemed overwhelming, but our movers handled everything perfectly. The GPS tracking gave us peace of mind, and our items arrived exactly when promised. Excellent cross-country service!",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default LongDistanceMoving;