import ServicePageTemplate from '@/components/ServicePageTemplate';
import residentialImage from '@/assets/residential-moving.jpg';

const PianoMoving = () => {
  const serviceData = {
    title: "Piano & Specialty Item Moving",
    subtitle: "Expert handling of pianos, antiques, artwork, and other valuable specialty items requiring special care",
    heroImage: residentialImage,
    description: "Moving a piano or other specialty items requires more than just muscle power - it demands expertise, specialized equipment, and years of experience handling these valuable and often irreplaceable pieces. Our piano and specialty item moving service is staffed by technicians who have been specially trained in the safe transportation of pianos, from upright models to full concert grand pianos. We understand that pianos are not just instruments but often cherished family heirlooms passed down through generations. Beyond pianos, we specialize in moving artwork, antiques, pool tables, safes, large appliances, and other items that require special handling due to their size, weight, fragility, or value. Our specialty moving team uses professional-grade equipment including piano dollies, skid boards, protective padding, and custom crating materials. We have successfully moved thousands of specialty items across Canada, earning the trust of music schools, concert halls, art galleries, and collectors who rely on our expertise to protect their most valuable possessions. Our service includes pre-move assessment, custom protection planning, specialized transportation, and careful placement in your new location. We also offer climate-controlled transportation for items sensitive to temperature and humidity changes.",
    features: [
      "Specialized training in piano moving techniques and safety",
      "Professional equipment including piano dollies and skid boards",
      "Custom crating and protection for valuable artwork and antiques",
      "Climate-controlled transportation for sensitive items",
      "Experienced team in handling heavy and awkward specialty items",
      "Pool table disassembly and reassembly services",
      "Safe and gun safe moving with proper equipment",
      "Art handling with museum-quality protection methods",
      "Full insurance coverage for high-value specialty items"
    ],
    process: [
      {
        step: "Specialty Item Assessment",
        description: "Our specialist examines your piano or valuable item to determine the best approach, equipment needed, and protection requirements."
      },
      {
        step: "Custom Protection Planning",
        description: "We create a detailed plan for protecting your item including custom padding, crating, or climate control as needed."
      },
      {
        step: "Specialized Equipment Setup",
        description: "Our team arrives with all necessary specialized equipment including piano dollies, lifting straps, and protective materials."
      },
      {
        step: "Expert Transportation",
        description: "Your specialty item is carefully loaded, secured, and transported using techniques specific to its type and value."
      },
      {
        step: "Precise Placement",
        description: "We carefully position your piano or specialty item in its new location and ensure it's properly set up and tuned if needed."
      }
    ],
    pricing: {
      title: "Specialty Item Pricing",
      description: "Custom quotes based on item type, size, and special requirements with full insurance coverage.",
      features: [
        "Custom quote for each item",
        "Specialized equipment included",
        "Professional assessment",
        "Climate control when needed",
        "Full insurance coverage",
        "Expert installation/setup",
        "Post-move inspection"
      ]
    },
    faqs: [
      {
        question: "What types of pianos can you move?",
        answer: "We move all types of pianos including upright pianos, baby grand pianos, full grand pianos, and digital pianos. Each requires different techniques and equipment."
      },
      {
        question: "Do you tune pianos after moving?",
        answer: "While we don't provide tuning services, we can recommend qualified piano tuners in your area. Most pianos need tuning after a move due to the change in environment."
      },
      {
        question: "Can you move artwork and antiques safely?",
        answer: "Yes, we use museum-quality packing and handling techniques for artwork and antiques, including custom crating, acid-free materials, and climate-controlled transportation."
      },
      {
        question: "How do you handle very heavy items like safes?",
        answer: "We have specialized equipment for moving heavy items including dollies, winches, and hydraulic lifts. Our team is trained in proper techniques for extremely heavy objects."
      },
      {
        question: "Do you disassemble and reassemble pool tables?",
        answer: "Yes, we provide complete pool table services including proper disassembly, transportation, and professional reassembly with level adjustment at your new location."
      },
      {
        question: "What insurance coverage do you provide for valuable items?",
        answer: "We provide comprehensive insurance coverage for specialty items and can arrange additional coverage for extremely high-value pieces. Coverage details are discussed during assessment."
      }
    ],
    testimonial: {
      name: "Margaret Foster",
      location: "Calgary, AB",
      text: "Moving my 1920s baby grand piano was my biggest worry. The moving team handled it like the precious heirloom it is. Not a scratch on it, and they even helped me find a piano tuner at my new home. Outstanding service!",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default PianoMoving;