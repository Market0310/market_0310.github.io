import ServicePageTemplate from '@/components/ServicePageTemplate';
import commercialImage from '@/assets/commercial-moving.jpg';

const StorageSolutions = () => {
  const serviceData = {
    title: "Storage Solutions",
    subtitle: "Secure, climate-controlled storage options for short-term and long-term needs during your move",
    heroImage: commercialImage,
    description: "Sometimes your move timeline doesn't align perfectly, or you need to store belongings temporarily or long-term during your transition. Our comprehensive storage solutions provide secure, clean, and climate-controlled facilities to keep your belongings safe for as long as needed. Whether you need storage for a few days between moves, several months while house hunting, or long-term storage for items you're not ready to part with, we have flexible options to meet your needs. Our modern storage facilities feature 24/7 security monitoring, climate control to protect sensitive items, and easy access when you need your belongings. We offer both self-storage options where you maintain access to your unit, and full-service storage where we handle everything including pickup, storage, inventory management, and delivery when you're ready. Our storage services are particularly popular with clients who are downsizing, military families with deployment storage needs, students storing items between semesters, and anyone whose new home isn't ready when their current lease expires. All storage services include professional moving to and from the facility, so you don't have to worry about transportation logistics.",
    features: [
      "Climate-controlled units to protect sensitive items from temperature extremes",
      "24/7 security monitoring with cameras and access control systems",
      "Flexible storage periods from short-term to long-term options",
      "Full-service storage with pickup, inventory, and delivery",
      "Self-access storage units for items you need occasionally",
      "Professional inventory management with detailed item tracking",
      "Insurance coverage for stored items included",
      "Clean, modern facilities with pest control programs",
      "Easy online account management and scheduling"
    ],
    process: [
      {
        step: "Storage Needs Assessment",
        description: "We assess your storage requirements including item types, quantity, duration, and access needs to recommend the best solution."
      },
      {
        step: "Facility Selection",
        description: "Choose from our network of secure, climate-controlled facilities based on your location preferences and storage needs."
      },
      {
        step: "Professional Pickup",
        description: "Our team carefully packs and transports your items to the storage facility using the same care as a regular move."
      },
      {
        step: "Secure Storage",
        description: "Items are stored in clean, climate-controlled units with detailed inventory tracking and 24/7 security monitoring."
      },
      {
        step: "Convenient Retrieval",
        description: "When you're ready, we can deliver all or some of your stored items to your new location with advance scheduling."
      }
    ],
    pricing: {
      title: "Flexible Storage Pricing",
      description: "Competitive monthly rates with no long-term contracts and transparent pricing.",
      features: [
        "No setup or administration fees",
        "Month-to-month flexibility",
        "Pickup and delivery included",
        "Climate control included",
        "Security monitoring included",
        "Insurance coverage included",
        "Online account management"
      ]
    },
    faqs: [
      {
        question: "How long can I store my items?",
        answer: "We offer flexible storage terms from as short as a few days to long-term storage for years. There are no minimum or maximum storage periods, and you can extend or end storage with just 30 days notice."
      },
      {
        question: "Are my belongings insured while in storage?",
        answer: "Yes, all stored items are covered by our comprehensive insurance policy. We can also arrange additional coverage for high-value items if needed."
      },
      {
        question: "Can I access my items while they're in storage?",
        answer: "For self-access units, you can visit during facility hours. For full-service storage, we can retrieve specific items with advance notice, or you can schedule access appointments."
      },
      {
        question: "What items cannot be stored?",
        answer: "We cannot store hazardous materials, perishable items, plants, pets, or illegal items. We'll review any questionable items during your assessment."
      },
      {
        question: "How do you protect items from damage in storage?",
        answer: "Our facilities are climate-controlled to prevent damage from temperature and humidity fluctuations. Items are also protected from pests, dust, and theft with our security systems."
      },
      {
        question: "Can you store just a few items or do I need a full unit?",
        answer: "We offer both full units and shared storage options. You only pay for the space you use, whether it's a few boxes or a full household."
      }
    ],
    testimonial: {
      name: "David Chen",
      location: "Edmonton, AB",
      text: "We needed to store our furniture for 3 months between selling our house and buying our new one. The storage facility was perfect - clean, secure, and climate controlled. When we were ready, they delivered everything in perfect condition.",
      rating: 5
    }
  };

  return <ServicePageTemplate {...serviceData} />;
};

export default StorageSolutions;